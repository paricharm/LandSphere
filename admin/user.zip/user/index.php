<div class="col-lg-11 col-md-11 col-12 container">
  <div class="card shadow">
    <div class="card-header">
        <!-- <div class="d-flex justify-content-around"> -->
            <h2 class="text-center text-primary">All User</h2>
            <!-- <a href="home.php?New_User" class="btn btn-info">+ User</a> -->
        <!-- </div> -->
    </div>
    <div class="card-body container">
      <table class="table table-hover table-bordered">
        <tr>
            <th>#</th>
            <th>User Name</th>
            <th>Email</th>
            <th>Course</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php
        $i=1;
        while($row = $all_user->fetch(PDO::FETCH_ASSOC))
        {
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= $row['email'] ?></td>
                <td><?= $row['title'] ?></td>
                <td><?= isset($row['status'])&&$row['status']==0?'<span class="p-2 rounded bg-success text-light">Active</span>':'<span class="p-2 rounded bg-danger text-light">Inactive</span>'; ?></td>
                <td>
                    <a href="home.php?Update_User&UserId=<?=$row['id']?>" class="btn btn-info"><i class="bi bi-pencil-square"></i></a>
                    <a href="delete.php?type=delete_user&UserId=<?=$row['id']?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                </td>
            </tr>
            <?php
        }
        ?>
      </table>
    </div>
  </div>
</div>