<?php
if(isset($_GET['Update_User']))
{
    if(isset($_GET['UserId']))
    {
        $id = $_GET['UserId'];
        $up_cat = $pdo->prepare("select * from user where id = '{$id}'");
        $up_cat->execute();
        $row_cat = $up_cat->fetch(PDO::FETCH_ASSOC);
        if(isset($_POST['update']))
        {
          $name = $_POST['name'];
          $email = $_POST['email'];
          if(!empty($name) || !empty($email))
          {
            $update = $pdo->prepare("update user set name='{$name}',email='{$email}' where id=$id");
            if($update->execute())
            {
              echo "<div class='alert alert-success'>User Detail Updated</div>";
            }
          }
        }
    }
}
if(isset($_GET['Update_User']))
{
    ?>
<div class="col-lg-10 col-md-10 col-12 container">
  <div class="card shadow">
    <div class="card-header">
      <h2 class="text-center text-primary">Update User</h2>
    </div>
    <div class="card-body container col-md-8 col-lg-8 col-10">
    <form action="" method="post">
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4">Name : </div>
            <div class="col-8"><input type="text" name="name" class="form-control" value="<?=$row_cat['name']?>"></div>
          </div>
        </div>
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4">Email : </div>
            <div class="col-8"><input type="text" name="email" class="form-control" value="<?=$row_cat['email']?>"></div>
          </div>
        </div>
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4"></div>
            <div class="col-8"><input type="submit" name="update" class="btn btn-default btn-outline-success col-12"></div>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>
    <?php
}
?>


