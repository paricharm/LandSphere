<?php
if(isset($_POST['register']))
{
  $name = $_POST['name'];
  if(!empty($name))
  {
    $insert = $pdo->prepare("insert into category(name)values('{$name}')");
    if($insert->execute())
    {
      echo "<div class='alert alert-success'>New Category Added!</div>";
    }else{
      exit;
    }
  }
}
?>
<div class="col-lg-10 col-md-10 col-12 container">
  <div class="card shadow">
    <div class="card-header">
      <h2 class="text-center text-primary">Make Category</h2>
    </div>
    <div class="card-body container col-md-8 col-lg-8 col-10">
      <form action="" method="post">
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4">Name : </div>
            <div class="col-8"><input type="text" name="name" class="form-control"></div>
          </div>
        </div>
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4"></div>
            <div class="col-8"><input type="submit" name="register" class="btn btn-default btn-outline-success col-12"></div>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>
