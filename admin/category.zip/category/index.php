<div class="col-lg-10 col-md-10 col-12 container">
  <div class="card shadow">
    <div class="card-header">
        <div class="d-flex justify-content-around">
            <h2 class="text-center text-primary">All Category</h2>
            <a href="home.php?New_Category" class="btn btn-info">+ Category</a>
        </div>
    </div>
    <div class="card-body container">
      <table class="table table-hover table-bordered">
        <tr>
            <th>#</th>
            <th>Category Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php
        $i=1;
        while($row = $all_cat->fetch(PDO::FETCH_ASSOC))
        {
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= isset($row['status'])&&$row['status']==0?'<span class="p-2 rounded bg-success">Active</span>':'<span class="p-2 rounded bg-danger">Inactive</span>'; ?></td>
                <td>
                    <a href="home.php?Update_Category&CatId=<?=$row['cat_id']?>" class="btn btn-info"><i class="bi bi-pencil-square"></i></a>
                    <a href="delete.php?type=delete_category&CatId=<?=$row['cat_id']?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                </td>
            </tr>
            <?php
        }
        ?>
      </table>
    </div>
  </div>
</div>