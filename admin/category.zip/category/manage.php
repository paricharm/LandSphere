<?php
if(isset($_GET['Update_Category']))
{
    if(isset($_GET['CatId']))
    {
        $id = $_GET['CatId'];
        $up_cat = $pdo->prepare("select * from category where cat_id = '{$id}'");
        $up_cat->execute();
        $row_cat = $up_cat->fetch(PDO::FETCH_ASSOC);
        if(isset($_POST['update']))
        {
          $name = $_POST['name'];
          if(!empty($name))
          {
            $insert = $pdo->prepare("update category set name='{$name}' where cat_id=$id");
            if($insert->execute())
            {
              echo "<div class='alert alert-success'>Category Updated!</div>";
            }else{
              exit;
            }
          }
        }
    }
}
if(isset($_GET['Update_Category']))
{
    ?>
<div class="col-lg-10 col-md-10 col-12 container">
  <div class="card shadow">
    <div class="card-header">
      <h2 class="text-center text-primary">Update Category</h2>
    </div>
    <div class="card-body container col-md-8 col-lg-8 col-10">
      <form action="" method="post">
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4">Name : </div>
            <div class="col-8"><input type="text" name="name" value="<?= $row_cat['name'] ?>" class="form-control"></div>
          </div>
        </div>
        <div class="form-group py-2">
          <div class="row">
            <div class="col-4"></div>
            <div class="col-8"><input type="submit" name="update" class="btn btn-default btn-outline-success col-12"></div>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>
    <?php
}
?>


