  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="dashboard.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="home.php?All_Category">
        <i class="bi bi-menu-button-wide"></i><span> Category</span>
       </a>
      </li><!-- End Components Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="home.php?All_Course">
        <i class="bi bi-menu-button-wide"></i><span> Course</span>
       </a>
      </li><!-- End Components Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="home.php?All_User">
        <i class="bi bi-menu-button-wide"></i><span> User</span>
       </a>
      </li><!-- End Components Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="home.php?All_Post">
        <i class="bi bi-menu-button-wide"></i><span> Post</span>
       </a>
      </li><!-- End Components Nav -->
      
      <li class="nav-item">
        <a class="nav-link collapsed" href="#">
          <i class="bi bi-journal-text"></i><span>Insights</span>
        </a>
      </li><!-- End Forms Nav -->
      
      <li class="nav-item">
        <a class="nav-link collapsed" href="#">
          <i class="bi bi-layout-text-window-reverse"></i><span>Marketplace</span>
        </a>
      </li><!-- End Tables Nav -->      
      <li class="nav-item">
        <a class="nav-link collapsed" href="logout.php">
        <i class="bi bi-menu-button-wide"></i><span> Logout</span>
       </a>
      </li><!-- End Components Nav -->
    </ul>

  </aside><!-- End Sidebar-->