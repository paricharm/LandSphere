<div class="col-lg-11 col-md-11 col-12 container">
  <div class="card shadow">
    <div class="card-header">
        <div class="d-flex justify-content-around">
            <h2 class="text-center text-primary">All Course</h2>
            <a href="home.php?New_Course" class="btn btn-info">+ Course</a>
        </div>
    </div>
    <div class="card-body container">
      <table class="table table-hover table-bordered">
        <tr>
            <th>#</th>
            <th>Course Name</th>
            <th>Duration</th>
            <th>Level</th>
            <th>Image</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php
        $i=1;
        while($row = $all_course->fetch(PDO::FETCH_ASSOC))
        {
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['title'] ?></td>
                <td><?= $row['time'] ?></td>
                <td><?= $row['level'] ?></td>
                <td><img src="<?= $row['img'] ?>" width="60" height="60" alt=""></td>
                <td><?= isset($row['status'])&&$row['status']==0?'<span class="p-2 rounded bg-success text-light">Active</span>':'<span class="p-2 rounded bg-danger text-light">Inactive</span>'; ?></td>
                <td>
                    <a href="home.php?Update_Course&CourseId=<?=$row['id']?>" class="btn btn-info"><i class="bi bi-pencil-square"></i></a>
                    <a href="delete.php?type=delete_course&CourseId=<?=$row['id']?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                </td>
            </tr>
            <?php
        }
        ?>
      </table>
    </div>
  </div>
</div>